#include "Shape.h"

class Rectangle : public Shape{

  public:
  virtual void draw(){}
  virtual double area();

  private:
  double width;
  


};