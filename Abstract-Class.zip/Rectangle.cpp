#include "Rectangle.h"

double Rectangle::area(){
  return length * width;
}