#include <iostream>
#include "Rectangle.h"

int main() {
  
  Dim2Shape shape;

}