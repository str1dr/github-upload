
class Dim2Shape {

public:
//abstract class
Dim2Shape(){}
// pure virtual function
virtual void draw() = 0;
virtual double area() = 0;

};